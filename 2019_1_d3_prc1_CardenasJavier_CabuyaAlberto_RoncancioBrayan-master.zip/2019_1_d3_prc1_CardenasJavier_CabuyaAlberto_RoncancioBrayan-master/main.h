
#ifndef MAIN_H
#define MAIN_H


#include "Bank.h"
#include "Interface.h"
#include <signal.h>

char exitkey;
Bank* banco1;
int main (int, char **);

#endif